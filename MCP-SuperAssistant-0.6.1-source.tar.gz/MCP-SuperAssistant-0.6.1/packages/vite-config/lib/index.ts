export * from './withPageConfig.js';
